# PartnerFlow — bản localhost

Website tiếng Việt quản lý đối tác, điền hợp đồng, lịch nhắc và đối soát hoa hồng.

## Chạy

Tại thư mục này, chạy:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory dist
```

Mở http://localhost:8000 trong trình duyệt. Dừng bằng Ctrl+C.

## Sử dụng

- Hồ sơ đối tác: thêm, sửa, tìm kiếm và xóa hồ sơ chưa có dữ liệu liên quan.
- Hợp đồng: chọn đối tác, điền dịch vụ, giá trị và thời hạn, xem và in/lưu PDF qua trình duyệt. Mẫu minh họa để trống thông tin bên cung cấp; cần hoàn thiện trước khi ký.
- Lịch nhắc: thêm, sửa, hoàn thành, mở lại hoặc xóa lịch; phân loại hôm nay, quá hạn, sắp tới.
- Hoa hồng: nhập doanh số đủ điều kiện và tỷ lệ, theo dõi chi trả, xem lịch sử và đối soát theo kỳ. Không cho ghi nhận chi trả vượt phần còn lại.
- Tổng quan: thống kê, các lịch cần theo dõi và xuất bản sao JSON.

## Giới hạn bản cục bộ

Dữ liệu mẫu hoàn toàn giả lập. Dữ liệu lưu trong localStorage của trình duyệt theo địa chỉ truy cập, không phải cơ sở dữ liệu dùng chung. Dùng nhất quán http://localhost:8000; địa chỉ 127.0.0.1 hoặc cổng khác sẽ có vùng dữ liệu riêng. Xóa dữ liệu trình duyệt sẽ mất dữ liệu đã lưu. Nút xuất bản sao tạo tệp JSON để giữ bản sao; bản này chưa có chức năng nhập lại.

Lịch nhắc chỉ hiển thị khi mở website, chưa gửi email/Zalo và chưa có tác vụ chạy nền. Chưa triển khai cloud hoặc đẩy code lên GitHub. Bản localhost dành cho thử nghiệm trên máy cá nhân, chưa có đăng nhập hoặc phân quyền.
